Visual preview only. Requests require WordPress + WooCommerce. Run: python3 -m http.server 4173 inside this folder, then open http://localhost:4173.
Map attribution and reusable ODbL source: data/delivery-basemap-LICENSE.md.
